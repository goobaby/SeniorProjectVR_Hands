Hello!

Thank you for downloading my Hand Asset Kit!
These assets are meant to use in tandem with the VR hand tutorial series I am createing on YouTube!

These files were made using student liscensed software, meaning you are unable to use them for commercial purposes. 
You can however utilize these models in your own personal projects. Though I would greatly appreciate it if you credited me. 
A simple link to my Youtube Page will do - { https://www.youtube.com/c/QuinnKuslich }

Thank you agian for downloading and I hope you have a good time with the tutorial series!

- Quinn Kuslich - 